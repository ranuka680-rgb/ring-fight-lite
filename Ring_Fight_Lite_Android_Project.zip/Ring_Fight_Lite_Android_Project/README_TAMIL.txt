RING FIGHT LITE — Android Studio project (prototype wrapper)

இந்த ZIP ஒரு Android Studio project source. இது APK file அல்ல.

APK உருவாக்க:
1. Computer-ல் Android Studio install செய்யவும்.
2. Android Studio-வில் இந்த folder-ஐ Open செய்யவும்.
3. Gradle sync முடியும் வரை காத்திருக்கவும்.
4. Build > Build APK(s) தேர்வு செய்யவும்.
5. APK உருவான பிறகு app-ஐ phone-ல் install செய்து test செய்யவும்.

கவனம்:
- இந்த build ஒரு lightweight HTML/WebView prototype-ஐ Android app-ஆக wrap செய்கிறது.
- இது full 3D game அல்ல; wrestler faces இன்னும் placeholder.
- APK size/performance phone-ல் build/test செய்த பிறகே உறுதியாக சொல்ல முடியும்.
- Android Studio/SDK உடன் computer தேவை. இந்த environment-ல் APK build செய்யப்படவில்லை.
